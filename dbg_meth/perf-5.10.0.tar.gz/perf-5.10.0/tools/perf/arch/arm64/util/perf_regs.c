// SPDX-License-Identifier: GPL-2.0
#include "../../../util/perf_regs.h"

const struct sample_reg sample_reg_masks[] = {
	SMPL_REG_END
};
