/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __TOOLS_PERF_SPARC_BARRIER_H
#define __TOOLS_PERF_SPARC_BARRIER_H

#include <asm-generic/barrier.h>

#endif /* !(__TOOLS_PERF_SPARC_BARRIER_H) */
