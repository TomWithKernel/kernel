#ifndef _LINUX_CONST_H
#define _LINUX_CONST_H

#include <vdso/const.h>

#endif /* _LINUX_CONST_H */
